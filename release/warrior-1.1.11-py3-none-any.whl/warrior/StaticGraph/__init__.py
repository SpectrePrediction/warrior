from .Operation.Operation import *
from .Graph.graph import *
from .Session.Session import *
from .Operation.nn import nn
from .Operation.train import train


# warrior.StaticGraph.Graph.graph.Graph
